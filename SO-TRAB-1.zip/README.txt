SAMUEL SILVEIRA PORDEUS - 11400947 - TRAB-SO-1
Inicie o script 'run.py' no terminal utilizando python3 com o comando:

python3 run.py
